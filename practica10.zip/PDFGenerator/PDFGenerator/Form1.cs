using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace PDFGenerator
{
	public partial class Form1 : Form
	{
		string selectedImagePath;

		public Form1()
		{
			InitializeComponent();
		}

		private void btnCreatePDF_Click(object sender, EventArgs e)
		{
			byte[] imageBytes = File.ReadAllBytes(selectedImagePath);

			var document = Document.Create(Container =>
			{
				Container.Page(page =>
				{
					page.Margin(1, Unit.Centimetre);

					page.Header().Height(35).Background(Colors.Grey.Medium).Text("Reporte de Usuario")
					.Bold().AlignCenter().FontSize(20).FontColor(Colors.White);

					page.Content().PaddingVertical(1, Unit.Centimetre).Column(x =>
					{
						x.Spacing(20);
						x.Item().Text(txtLyric.Text).AlignCenter();
						x.Item().Image(imageBytes);
					});

					page.Footer().Height(25).Background(Colors.Grey.Medium);
				});
			});

			document.GeneratePdfAndShow();
		}

		private void btnInsertImage_Click(object sender, EventArgs e)
		{
			ofdImage.Title = "Selecciona tu imagen";
			ofdImage.ShowDialog();

			if (File.Exists(ofdImage.FileName))
			{
				selectedImagePath = ofdImage.FileName;
			}
		}
	}
}
