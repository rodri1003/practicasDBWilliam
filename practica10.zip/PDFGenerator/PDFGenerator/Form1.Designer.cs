﻿namespace PDFGenerator
{
	partial class Form1
	{
		/// <summary>
		///  Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		///  Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		///  Required method for Designer support - do not modify
		///  the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			btnCreatePDF = new Button();
			txtLyric = new TextBox();
			label1 = new Label();
			ofdImage = new OpenFileDialog();
			btnInsertImage = new Button();
			SuspendLayout();
			// 
			// btnCreatePDF
			// 
			btnCreatePDF.Location = new Point(49, 234);
			btnCreatePDF.Name = "btnCreatePDF";
			btnCreatePDF.Size = new Size(377, 29);
			btnCreatePDF.TabIndex = 0;
			btnCreatePDF.Text = "GENERAR PDF";
			btnCreatePDF.UseVisualStyleBackColor = true;
			btnCreatePDF.Click += btnCreatePDF_Click;
			// 
			// txtLyric
			// 
			txtLyric.Location = new Point(49, 48);
			txtLyric.Multiline = true;
			txtLyric.Name = "txtLyric";
			txtLyric.Size = new Size(377, 120);
			txtLyric.TabIndex = 1;
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.Location = new Point(113, 18);
			label1.Name = "label1";
			label1.Size = new Size(229, 15);
			label1.TabIndex = 2;
			label1.Text = "Digite una parte de la letra de una cancion";
			// 
			// btnInsertImage
			// 
			btnInsertImage.Location = new Point(49, 190);
			btnInsertImage.Name = "btnInsertImage";
			btnInsertImage.Size = new Size(377, 29);
			btnInsertImage.TabIndex = 3;
			btnInsertImage.Text = "INSERTAR IMAGEN";
			btnInsertImage.UseVisualStyleBackColor = true;
			btnInsertImage.Click += btnInsertImage_Click;
			// 
			// Form1
			// 
			AutoScaleDimensions = new SizeF(7F, 15F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(473, 275);
			Controls.Add(btnInsertImage);
			Controls.Add(label1);
			Controls.Add(txtLyric);
			Controls.Add(btnCreatePDF);
			Name = "Form1";
			Text = "Form1";
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private Button btnCreatePDF;
		private TextBox txtLyric;
		private Label label1;
		private OpenFileDialog ofdImage;
		private Button btnInsertImage;
	}
}
