﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace APIMongo_Peliculas.Models
{
	public class Movie
	{
		[BsonId]
		[BsonRepresentation(BsonType.ObjectId)]
		public string? Id { get; set; }

		[BsonElement("Name")]
		public string MovieName { get; set; } = null!;

		public string Duration { get; set; }

		public string Category { get; set; } = null!;

		public string Author { get; set; } = null!;
	}
}
