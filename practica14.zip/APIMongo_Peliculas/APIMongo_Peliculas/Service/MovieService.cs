﻿using APIMongo_Peliculas.Models;
using Microsoft.Extensions.Options;
using MongoDB.Driver;

namespace APIMongo_Peliculas.Service
{
	public class MovieService
	{
		private readonly IMongoCollection<Movie> _movieCollection;

        public MovieService(IOptions<NeisflisDatabaseSettings> neisflisDatabaseSettings)
        {
            var mongoClient = new MongoClient(neisflisDatabaseSettings.Value.ConnectionString);

            var mongoDatabase = mongoClient.GetDatabase(neisflisDatabaseSettings.Value.DatabaseName);

            _movieCollection = mongoDatabase.GetCollection<Movie>(neisflisDatabaseSettings.Value.NeisflisCollectionName);
        }

        public async Task<List<Movie>> GetAsync() => await _movieCollection.Find(_ => true).ToListAsync();
        public async Task<Movie?> GetAsync(string id) => await _movieCollection.Find(x => x.Id == id).FirstOrDefaultAsync();
        public async Task CreateAsync(Movie newMovie) => await _movieCollection.InsertOneAsync(newMovie);
        public async Task UpdateAsync(string id,Movie newMovie) => await _movieCollection.ReplaceOneAsync( x => x.Id == id, newMovie);
        public async Task RemoveAsync(string id) => await _movieCollection.DeleteOneAsync( x => x.Id == id);
    }
}
